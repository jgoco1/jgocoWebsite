scoreboard players operation @s ea_prev = @s ea_anvil_stat
function flexible_enchants:clear_repair_cost
