execute as @a if score @s ea_anvil_stat > @s ea_prev run function flexible_enchants:on_anvil_open
