scoreboard objectives add ea_anvil_stat minecraft.custom:minecraft.interact_with_anvil
scoreboard objectives add ea_prev dummy
tellraw @a [{"text":"[Flexible Enchants] ","color":"gold"},{"text":"loaded - exclusive enchantments can now combine, many enchantments cost less on the anvil, and prior-work costs are cleared automatically."}]
