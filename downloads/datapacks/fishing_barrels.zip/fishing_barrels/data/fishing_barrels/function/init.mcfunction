execute as @a at @s run function fishing_barrels:init_scan
tellraw @a {"text":"[Fishing Barrels] Scan complete - nearby qualifying barrels are now active.","color":"gold"}
