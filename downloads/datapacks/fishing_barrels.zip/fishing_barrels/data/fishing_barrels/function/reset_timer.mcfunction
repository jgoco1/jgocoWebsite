execute store result score @s fb_timer run random value 200..600
scoreboard players operation @s fb_timer /= @s fb_count
