execute store result score @s fb_timer run random value 200..600
