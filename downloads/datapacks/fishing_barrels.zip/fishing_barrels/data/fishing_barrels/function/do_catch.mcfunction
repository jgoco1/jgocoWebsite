loot insert ~ ~ ~ loot minecraft:gameplay/fishing
function fishing_barrels:reset_timer
