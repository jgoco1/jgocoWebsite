summon minecraft:marker ~ ~ ~ {Tags:["fishing_barrel_marker"]}
execute as @e[tag=fishing_barrel_marker,distance=..0.6,sort=nearest,limit=1] run function fishing_barrels:reset_timer
