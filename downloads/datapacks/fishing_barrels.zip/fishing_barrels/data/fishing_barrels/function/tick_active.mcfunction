scoreboard players remove @s fb_timer 1
execute if score @s fb_timer matches ..0 run function fishing_barrels:do_catch
