execute unless block ~ ~ ~ minecraft:barrel run function fishing_barrels:remove_marker
execute if block ~ ~ ~ minecraft:barrel run function fishing_barrels:process
