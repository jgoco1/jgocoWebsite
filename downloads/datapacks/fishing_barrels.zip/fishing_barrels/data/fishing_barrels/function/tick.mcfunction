execute as @e[type=minecraft:marker,tag=fishing_barrel_marker] at @s run function fishing_barrels:marker_tick
