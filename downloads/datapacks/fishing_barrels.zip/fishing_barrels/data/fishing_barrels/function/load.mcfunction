scoreboard objectives add fb_count dummy
scoreboard objectives add fb_timer dummy
tellraw @a [{"text":"[Fishing Barrels] ","color":"gold"},{"text":"loaded. Run "},{"text":"/function fishing_barrels:init","color":"yellow"},{"text":" once to activate any qualifying barrels already placed in the world."}]
