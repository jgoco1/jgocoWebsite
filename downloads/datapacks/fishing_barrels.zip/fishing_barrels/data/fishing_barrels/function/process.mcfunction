scoreboard players set @s fb_count 0
execute if block ~ ~1 ~ minecraft:water run scoreboard players add @s fb_count 1
execute if block ~ ~-1 ~ minecraft:water run scoreboard players add @s fb_count 1
execute if block ~ ~ ~1 minecraft:water run scoreboard players add @s fb_count 1
execute if block ~ ~ ~-1 minecraft:water run scoreboard players add @s fb_count 1
execute if block ~1 ~ ~ minecraft:water run scoreboard players add @s fb_count 1
execute if block ~-1 ~ ~ minecraft:water run scoreboard players add @s fb_count 1
execute if score @s fb_count matches 3.. run function fishing_barrels:tick_active
