execute if block ~ ~ ~ minecraft:barrel unless entity @e[tag=fishing_barrel_marker,distance=..0.6] run function fishing_barrels:place_marker
