scoreboard objectives add msb_timer dummy
scoreboard objectives add msb_has dummy
scoreboard players set #global msb_timer 0
tellraw @a [{"text":"[Mining Speed Boost] ","color":"gold"},{"text":"loaded - all players mine slightly faster with the correct tool."}]
