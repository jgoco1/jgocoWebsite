tellraw @a [{"text":"[Mining Speed Boost] ","color":"gold"},{"text":"loaded - all players mine slightly faster with the correct tool."}]
