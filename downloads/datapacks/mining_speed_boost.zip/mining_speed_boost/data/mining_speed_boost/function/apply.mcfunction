attribute @s minecraft:mining_efficiency modifier add mining_speed_boost:bonus 11 add_value
