execute store success score @s msb_has run attribute @s minecraft:mining_efficiency modifier value get mining_speed_boost:bonus
execute if score @s msb_has matches 0 run function mining_speed_boost:apply
