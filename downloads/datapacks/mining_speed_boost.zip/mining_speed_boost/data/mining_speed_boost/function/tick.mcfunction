scoreboard players add #global msb_timer 1
execute if score #global msb_timer matches 20.. run scoreboard players set #global msb_timer 0
execute if score #global msb_timer matches 0 as @a run function mining_speed_boost:check
