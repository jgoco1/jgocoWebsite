execute as @a[tag=!msb_boosted] run function mining_speed_boost:apply
