execute if block ~ ~ ~ minecraft:furnace unless entity @e[tag=furnace_quarry_weak_marker,distance=..0.6] run function furnace_quarry:place_marker_weak
