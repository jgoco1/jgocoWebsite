summon minecraft:marker ~ ~ ~ {Tags:["furnace_quarry_marker"]}
execute as @e[tag=furnace_quarry_marker,distance=..0.6,sort=nearest,limit=1] run function furnace_quarry:reset_timer
