execute store result score @s qz_timer run random value 300..600
