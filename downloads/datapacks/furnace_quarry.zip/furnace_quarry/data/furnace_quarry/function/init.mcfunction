execute as @a at @s run function furnace_quarry:init_scan
execute as @a at @s run function furnace_quarry:init_scan_weak
tellraw @a {"text":"[Furnace Quarry] Scan complete - nearby qualifying blast furnaces and furnaces are now active.","color":"gold"}
