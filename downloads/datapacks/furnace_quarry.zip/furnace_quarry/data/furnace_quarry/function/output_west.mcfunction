$loot insert ~-1 ~ ~ loot $(table)
scoreboard players set @s qz_done 1
