scoreboard objectives add qz_timer dummy
scoreboard objectives add qz_between dummy
scoreboard objectives add qz_done dummy
scoreboard objectives add qz_roll dummy
scoreboard objectives add qz_y dummy
scoreboard objectives add qz_weak_timer dummy
scoreboard players set #global qz_weak_timer 0
tellraw @a [{"text":"[Furnace Quarry] ","color":"gold"},{"text":"loaded. Run "},{"text":"/function furnace_quarry:init","color":"yellow"},{"text":" once to activate any qualifying blast furnaces and furnaces already placed in the world."}]
