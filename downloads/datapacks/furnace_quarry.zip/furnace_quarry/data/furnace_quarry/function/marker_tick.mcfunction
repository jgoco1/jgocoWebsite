execute unless block ~ ~ ~ minecraft:blast_furnace run function furnace_quarry:remove_marker
execute if block ~ ~ ~ minecraft:blast_furnace run function furnace_quarry:process
