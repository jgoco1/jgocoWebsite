scoreboard players set @s qz_between 0
execute if block ~ ~1 ~ minecraft:lava[level=0] if block ~ ~-1 ~ minecraft:water[level=0] run scoreboard players set @s qz_between 1
execute if block ~ ~1 ~ minecraft:water[level=0] if block ~ ~-1 ~ minecraft:lava[level=0] run scoreboard players set @s qz_between 1
execute if block ~ ~ ~1 minecraft:lava[level=0] if block ~ ~ ~-1 minecraft:water[level=0] run scoreboard players set @s qz_between 1
execute if block ~ ~ ~1 minecraft:water[level=0] if block ~ ~ ~-1 minecraft:lava[level=0] run scoreboard players set @s qz_between 1
execute if block ~1 ~ ~ minecraft:lava[level=0] if block ~-1 ~ ~ minecraft:water[level=0] run scoreboard players set @s qz_between 1
execute if block ~1 ~ ~ minecraft:water[level=0] if block ~-1 ~ ~ minecraft:lava[level=0] run scoreboard players set @s qz_between 1
execute if score @s qz_between matches 1 run function furnace_quarry:tick_active
