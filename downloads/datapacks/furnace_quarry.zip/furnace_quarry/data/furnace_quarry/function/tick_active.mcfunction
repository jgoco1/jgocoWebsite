scoreboard players remove @s qz_timer 1
execute if score @s qz_timer matches ..0 run function furnace_quarry:do_catch
