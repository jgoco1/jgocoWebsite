scoreboard players add #global qz_weak_timer 1
execute if score #global qz_weak_timer matches 20.. run scoreboard players set #global qz_weak_timer 0
execute as @e[type=minecraft:marker,tag=furnace_quarry_marker] at @s run function furnace_quarry:marker_tick
execute as @e[type=minecraft:marker,tag=furnace_quarry_weak_marker] at @s run function furnace_quarry:marker_tick_weak
