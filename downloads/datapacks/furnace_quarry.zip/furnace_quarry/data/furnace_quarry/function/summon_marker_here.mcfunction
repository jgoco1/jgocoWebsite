execute if block ~ ~ ~ minecraft:blast_furnace unless entity @e[tag=furnace_quarry_marker,distance=..0.6] run function furnace_quarry:place_marker
