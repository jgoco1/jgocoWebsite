execute unless block ~ ~ ~ minecraft:furnace run function furnace_quarry:remove_marker
execute if block ~ ~ ~ minecraft:furnace if score #global qz_weak_timer matches 0 run function furnace_quarry:process_weak
