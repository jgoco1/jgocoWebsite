execute store result score @s qz_y run data get entity @s Pos[1] 1
execute if score @s qz_y matches ..-17 run data modify storage furnace_quarry:vars table set value "furnace_quarry:ore_pool_weak_deep"
execute if score @s qz_y matches -16..31 run data modify storage furnace_quarry:vars table set value "furnace_quarry:ore_pool_weak_mid"
execute if score @s qz_y matches 32..79 run data modify storage furnace_quarry:vars table set value "furnace_quarry:ore_pool_weak_upper"
execute if score @s qz_y matches 80.. run data modify storage furnace_quarry:vars table set value "furnace_quarry:ore_pool_weak_surface"
