summon minecraft:marker ~ ~ ~ {Tags:["furnace_quarry_weak_marker"]}
