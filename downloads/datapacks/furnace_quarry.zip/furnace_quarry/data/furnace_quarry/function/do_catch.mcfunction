function furnace_quarry:select_table
scoreboard players set @s qz_done 0
execute if score @s qz_done matches 0 if block ~ ~-1 ~ #furnace_quarry:containers run function furnace_quarry:output_down with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~ ~1 ~ #furnace_quarry:containers run function furnace_quarry:output_up with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~ ~ ~-1 #furnace_quarry:containers run function furnace_quarry:output_north with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~ ~ ~1 #furnace_quarry:containers run function furnace_quarry:output_south with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~1 ~ ~ #furnace_quarry:containers run function furnace_quarry:output_east with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~-1 ~ ~ #furnace_quarry:containers run function furnace_quarry:output_west with storage furnace_quarry:vars
function furnace_quarry:reset_timer
