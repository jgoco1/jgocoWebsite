execute store result score @s qz_roll run random value 1..1000
execute if score @s qz_roll matches 1..15 run function furnace_quarry:do_catch_weak
