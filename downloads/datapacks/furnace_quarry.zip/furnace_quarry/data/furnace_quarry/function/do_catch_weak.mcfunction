function furnace_quarry:select_table_weak
scoreboard players set @s qz_done 0
execute if score @s qz_done matches 0 if block ~ ~-1 ~ #furnace_quarry:containers run function furnace_quarry:output_down_weak with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~ ~1 ~ #furnace_quarry:containers run function furnace_quarry:output_up_weak with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~ ~ ~-1 #furnace_quarry:containers run function furnace_quarry:output_north_weak with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~ ~ ~1 #furnace_quarry:containers run function furnace_quarry:output_south_weak with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~1 ~ ~ #furnace_quarry:containers run function furnace_quarry:output_east_weak with storage furnace_quarry:vars
execute if score @s qz_done matches 0 if block ~-1 ~ ~ #furnace_quarry:containers run function furnace_quarry:output_west_weak with storage furnace_quarry:vars
