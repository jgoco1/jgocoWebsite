effect give @a[distance=..16] minecraft:regeneration 2 0 true
effect give @e[type=#campfire_aura:allies,distance=..16] minecraft:regeneration 2 0 true
effect give @e[type=minecraft:iron_golem,distance=..32] minecraft:regeneration 2 0 true
execute as @e[type=#campfire_aura:hostile,distance=..32] run damage @s 2 minecraft:magic
