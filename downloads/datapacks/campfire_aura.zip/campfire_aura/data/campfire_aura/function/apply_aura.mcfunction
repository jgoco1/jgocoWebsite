execute if block ~ ~-1 ~ minecraft:hay_block run function campfire_aura:do_effects_boosted
execute unless block ~ ~-1 ~ minecraft:hay_block run function campfire_aura:do_effects_normal
