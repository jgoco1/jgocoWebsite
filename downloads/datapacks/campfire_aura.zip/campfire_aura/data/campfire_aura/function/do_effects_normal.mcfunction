effect give @a[distance=..8] minecraft:regeneration 2 0 true
execute as @e[type=#campfire_aura:hostile,distance=..16] run damage @s 2 minecraft:magic
