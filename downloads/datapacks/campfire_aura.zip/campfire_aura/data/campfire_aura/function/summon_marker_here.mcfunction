execute if block ~ ~ ~ #campfire_aura:campfires unless entity @e[tag=campfire_aura_marker,distance=..0.6] run summon minecraft:marker ~ ~ ~ {Tags:["campfire_aura_marker"]}
