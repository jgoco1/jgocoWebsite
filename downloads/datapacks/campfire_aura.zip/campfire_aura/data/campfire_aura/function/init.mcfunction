execute as @a at @s run function campfire_aura:init_scan
tellraw @a {"text":"[Campfire Aura] Scan complete - nearby existing campfires are now active.","color":"gold"}
