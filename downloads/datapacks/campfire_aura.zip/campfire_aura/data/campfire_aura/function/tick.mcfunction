scoreboard players add #global ca_timer 1
execute if score #global ca_timer matches 20.. run scoreboard players set #global ca_timer 0
execute as @e[type=minecraft:marker,tag=campfire_aura_marker] at @s run function campfire_aura:marker_tick
