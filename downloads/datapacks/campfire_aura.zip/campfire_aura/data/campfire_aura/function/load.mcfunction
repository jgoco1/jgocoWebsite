scoreboard objectives add ca_timer dummy
scoreboard players set #global ca_timer 0
tellraw @a [{"text":"[Campfire Aura] ","color":"gold"},{"text":"loaded. Run "},{"text":"/function campfire_aura:init","color":"yellow"},{"text":" once to activate any campfires already placed in the world. Place a campfire on a hay bale to double its radius."}]
