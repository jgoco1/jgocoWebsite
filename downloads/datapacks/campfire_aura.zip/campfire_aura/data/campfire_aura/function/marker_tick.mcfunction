execute unless block ~ ~ ~ #campfire_aura:campfires run function campfire_aura:remove_marker
execute if block ~ ~ ~ minecraft:campfire[lit=true] if score #global ca_timer matches 0 run function campfire_aura:apply_aura
execute if block ~ ~ ~ minecraft:soul_campfire[lit=true] if score #global ca_timer matches 0 run function campfire_aura:apply_aura
